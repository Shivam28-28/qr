import qrcode

# Function to create a QR code dynamically
def generate_dynamic_qr_code():
    # Set the data and output file
    data_to_encode = "https://hemrajat.in/"
    output_file = "shivdigiforest05_qr_code.png"

    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(data_to_encode)
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white")

    # Save the QR code as an image file
    img.save(output_file)
    print(f"QR code generated and saved as {output_file}")

# Call the function to generate a dynamic QR code
generate_dynamic_qr_code()
